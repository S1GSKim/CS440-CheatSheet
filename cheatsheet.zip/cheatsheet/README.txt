Congratulations you are one step closer to getting the A+ of your dreams!

To obtain the cheatsheets, enter the cheatsheet folder.
You will see items, cutecheatsheet.sh and generatecheatsheet.exe

Run the program using the following steps:
1. Open your terminal (Macbook users) or Command prompt (Windows users).
2. Navigate to your downloaded cheatsheet folder.
3. Run the command "bash cutecheatsheet.sh". This will execute the program to generate all the cheatsheets
4. All the best for your finals!
